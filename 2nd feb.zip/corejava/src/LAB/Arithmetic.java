package LAB;
public class Arithmetic {//create class
	public static void main(String[] args) {//main method
		int a=125,b=24,sum,sub,mul,div,mod;
		System.out.println("the first value is:"+a);
		System.out.println("the second value is:"+b);
		sum=a+b;//addition
		System.out.println("the sum is:"+sum);
		sub=a-b;//subtraction
		System.out.println("the sub is:"+sub);
		mul=a*b;//multiplication
		System.out.println("the mul is:"+mul);
		div=a/b;//division
		System.out.println("the div is:"+div);
		mod=a%b;//modulus
		System.out.println("the mod is:"+mod);
	}

}
