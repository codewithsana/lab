package LAB;

public class ExpressionProgram {
public static void main(String[] args) {
	double a=25.5,b=3.5,c=40.5,d=4.5,exp;
	exp =(a*b-b*b)/(c-d);
	//exp=(25.5*3.5-3.5*3.5)/(40.5-4.5);
	System.out.println("the expression is:"+exp);
}
}
